#ifndef __PUBLIC__RTEMSAPI_H__
#define __PUBLIC__RTEMSAPI_H__

/*PROTECTED REGION ID(public_rtemsapi_h) ENABLED START*/


    // This is a protected region as long as you keep the marks :-)


/*PROTECTED REGION END*/

#endif // __PUBLIC__RTEMSAPI_H__
