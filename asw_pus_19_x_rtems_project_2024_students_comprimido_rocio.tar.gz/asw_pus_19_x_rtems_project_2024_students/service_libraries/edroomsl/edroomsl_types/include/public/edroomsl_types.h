#ifndef __PUBLIC__EDROOMSL_TYPES_H__
#define __PUBLIC__EDROOMSL_TYPES_H__

// Interface definition

#include "../edroomsl_types/edroomsl_types.h"

#endif // __PUBLIC__EDROOMSL_TYPES_H__
