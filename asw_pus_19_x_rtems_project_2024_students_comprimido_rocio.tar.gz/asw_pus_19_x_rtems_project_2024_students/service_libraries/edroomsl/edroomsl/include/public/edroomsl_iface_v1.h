#ifndef __PUBLIC__EDROOMSL_H__
#define __PUBLIC__EDROOMSL_H__

// Interface definition

#define EDROOMUINT32_MAX 0xFFFFFFFF

#include "../edroomsl/edroomsl.h"

#endif // __PUBLIC__EDROOMSL_H__
